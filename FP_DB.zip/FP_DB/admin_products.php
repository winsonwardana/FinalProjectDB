	<?php 
	include("database/config.php");

	$queryGetOrderProducts = mysqli_query($connection,"SELECT * FROM productitem");
	# FUNCTION FOR ADD PRODUCT
	if (isset($_POST['addProduct'])) {
		$itemName = mysqli_real_escape_string($connection, $_POST['item_name']);
		$itemPriceSmall = mysqli_real_escape_string($connection, $_POST['item_priceSmall']);
		$itemPriceMedium = mysqli_real_escape_string($connection, $_POST['item_priceMedium']);
		$itemPriceBig = mysqli_real_escape_string($connection, $_POST['item_priceBig']);

	    $queryAdd = "INSERT INTO productitem 
	      (productName,priceS, priceM,priceB) 
	      VALUES 
	      ('$itemName', $itemPriceSmall ,  $itemPriceMedium , $itemPriceBig ) ";
	    	if(mysqli_query($connection, $queryAdd));{

			header("Location: admin_products.php");

	    }
	}



	 ?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Grandma's Cookies</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


	    <link rel="stylesheet" href="main.css">
	    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>	
	    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="js/smoothScroll.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
		<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
		<!-- Bootstrap Date-Picker Plugin -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
		<style type="text/css">
		.video-container {
		  position: relative;
		}

		.overlay-desc {
		  background: rgba(0,0,0,0);
		  position: absolute;
		  top: 0; right: 0; bottom: 0; left: 0;
		  display: flex;
		  align-items: center;
		  justify-content: center;
		  margin-bottom: 100px
		}
		.header-link{
			color: black
		}
		.header-link:hover{
			color: blue
		}
		</style>
	</head>
	<body style="background-color: white">
		<div class="row bg-light" style="padding: 20px 0px 20px 10px">

			<div class="col-md-11">
				
				<nav class="navbar navbar-expand-lg ">
					
					<a class="navbar-brand header-link" href="admin_order.php?order-on_going" style="font-size: 20px;">Orders</a>
					<a class="navbar-brand header-link" href="admin_products.php" style="font-size: 20px;margin-left: 10px;">Products</a>
				</nav>
			</div>
			<div class="col-md-1" style="margin-left: -50px">
				
				<nav class="navbar navbar-expand-lg ">
					
					
					<a class="navbar-brand header-link" href="index.php" style="font-size: 20px;margin-left: 10px;">Logout</a>
				</nav>
			</div>

		</div>
		<div class="row" style="text-align: center;margin-top: 30px">
			<div class="col-md-12">
				<h1>PRODUCTS MANAGEMENT</h1>

			</div>
		</div>
		<div class="row" style="padding: 0px 300px;margin-top: 50px">
			
		</div>

		<div class="row" style="padding: 0px 300px 0px 300px;">	
		
			<div class="col-md-8" style="padding-left: 0px">

				  <div class="form-group">
					<table class="table table-striped">
					  <thead>
					    <tr>
					      <th scope="col">#</th>
					      <th scope="col">Name</th>
					      <th scope="col">Small Price</th>
					      <th scope="col">Medium Price</th>
					      <th scope="col">Big Price</th>
					      <th scope="col">Action</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php  
					  	$num = 1;
						if (mysqli_num_rows($queryGetOrderProducts) > 0) { 
				    		while ($row=mysqli_fetch_array($queryGetOrderProducts)) {
						?>
					    <tr>
					      <th scope="row"><?php 	echo $num; ?></th>
					      <td><?php echo $row["productName"] ?></td>
					      <td><?php echo $row["priceS"] ?></td>
					      <td><?php echo $row["priceM"] ?></td>
					      <td><?php echo $row["priceB"] ?></td>
					      <td>
						     <a href="action/delete_product.php?delete=<?php echo $row["productID"] ?>">
						      		<button name="deleteItem" type="button" class=" btn btn-danger" style="border: 0px;border-radius: 5px;width: 100%;height: 35px;color: white">
			                Delete</button>
						     </a>
							      	
						   </td>
 						  				    
						  </tr>
								<?php $num+=1;	}} ?>
					  </tbody>
					</table>				  
				</div>

</div>
<div class="col-md-4" style="background: black;border-radius: 5px;padding: 10px ; height: 290px !important">

				<form action=""  method="post"  role="form">
					
				  <div class="form-group">
				    <input type="text" class="form-control" name="item_name" placeholder="Insert Product Name" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
				  <div class="form-group">
				    <input type="text" class="form-control" name="item_priceSmall" placeholder="Insert Small Size's Price" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
				  <div class="form-group">
				    <input type="text" class="form-control" name="item_priceMedium" placeholder="Insert Medium Size's Price"" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
				  <div class="form-group">
				    <input type="text" class="form-control" name="item_priceBig"  placeholder="Insert Big Size's Price"" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
				  <button name="addProduct"  style="width: 100%" type="submit" class="btn btn-primary">ADD ITEM</button>

				  
				</form>
			</div>
		</div>
				  
				

	</body>
	</html>