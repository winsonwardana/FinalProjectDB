	<?php 
	session_start();

	include("database/config.php");

	$queryGetOrderHistory = mysqli_query($connection,"SELECT * FROM orders, customer, status WHERE customer.custID = orders.custID AND orders.statusID = status.statusID AND orders.statusID = 1");

	$queryGetOrderHistory2 = mysqli_query($connection,"SELECT * FROM orders, customer, status WHERE customer.custID = orders.custID AND orders.statusID = status.statusID AND orders.statusID = 2");

	$queryGetOrderHistory3 = mysqli_query($connection,"SELECT * FROM orders, customer, status WHERE customer.custID = orders.custID AND orders.statusID = status.statusID AND orders.statusID = 3");
	
	if (isset($_POST['search1'])) {
	$query_search = mysqli_query($connection,"SELECT * FROM orders WHERE orderID = {$_POST['searchID']}");
	if (mysqli_num_rows($query_search) > 0) { 
    	while ($row=mysqli_fetch_array($query_search)) {
		header("Location:  admin_order.php?order-detail={$_POST['searchID']}"
);
	 	}
	}
	else{
		header("Location:history.php?notFound");

	}
}
	 ?>




	<!DOCTYPE html>
	<html>
	<head>
		<title>Grandma's Cookies</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


	    <link rel="stylesheet" href="main.css">
	    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>	
	    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="js/smoothScroll.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
		<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
		<!-- Bootstrap Date-Picker Plugin -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
		<style type="text/css">
		.video-container {
		  position: relative;
		}

		.overlay-desc {
		  background: rgba(0,0,0,0);
		  position: absolute;
		  top: 0; right: 0; bottom: 0; left: 0;
		  display: flex;
		  align-items: center;
		  justify-content: center;
		  margin-bottom: 100px
		}
		.header-link{
			color: black
		}
		.header-link:hover{
			color: blue
		}
		</style>
	</head>
	<body style="background-color: white">
		<div class="row bg-light" style="padding: 20px 0px 20px 10px">

			<div class="col-md-11">
				
				<nav class="navbar navbar-expand-lg ">
					
					<a class="navbar-brand header-link" href="admin_order.php?order-on_going" style="font-size: 20px;">Orders</a>
					<a class="navbar-brand header-link" href="admin_products.php" style="font-size: 20px;margin-left: 10px;">Products</a>
				</nav>
			</div>
			<div class="col-md-1" style="margin-left: -50px">
				
				<nav class="navbar navbar-expand-lg ">
					
					
					<a class="navbar-brand header-link" href="index.php" style="font-size: 20px;margin-left: 10px;">Logout</a>
				</nav>
			</div>

		</div>	
	<?php if(isset($_GET["order-on_going"])) { ?>
		<div class="row" style="text-align: center;margin-top: 30px">
			<div class="col-md-12">
							<h1>ORDER HISTORY</h1>

			</div>
		</div>
		<div class="row" style="margin-top: 30px;">
			<div class="col-md-12">
				
				<nav class="navbar navbar-expand-lg ">
					
					<a class="navbar-brand header-link" href="admin_order.php?order-on_going" style="font-size: 20px;margin-left: 10px;text-decoration: underline">On-Going</a>
					<a class="navbar-brand header-link" href="admin_order.php?order-paid" style="font-size: 20px;margin-left: 10px;">Paid</a>
					<a class="navbar-brand header-link" href="admin_order.php?order-delivered" style="font-size: 20px;margin-left: 10px;">Delivered</a>
				</nav>
			</div>
			<div class="col-md-12" style="padding-left: 40px">
				<form class="form-inline my-2 my-lg-0" style="text-align: right !important" action="" method="post">
			      <input name="searchID" class="form-control mr-sm-2" type="search" placeholder="Search By ID" aria-label="Search">
			      <button name="search1" class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
			    </form>
			</div>
			<div class="col-md-12" style="padding: 15px 40px" >

					<table class="table table-striped">
					  <thead>
					    <tr>
					      <th scope="col">id</th>
					      <th scope="col">Status</th>
					      <th scope="col">Name</th>
					      <th scope="col">Email</th>
					      <th scope="col">Phone Number</th>
					      <th scope="col">Date Ordered</th>
					      <th scope="col">Action</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php  
						if (mysqli_num_rows($queryGetOrderHistory) > 0) { 
				    		while ($row=mysqli_fetch_array($queryGetOrderHistory)) {
						?>
					    <tr>
					      <th scope="row"><?php echo $row["orderID"] ?></th>
					      <td><?php echo $row["statusName"] ?></td>
					      <td><?php echo $row["custName"] ?></td>
					      <td><?php echo $row["email"] ?></td>
					      <td><?php echo $row["phone"] ?></td>
					      <td><?php echo $row["bill_date"] ?></td>
 						  <td>
 						  	<div class="row">
 						  		<div class="col-md-6">
 						  			<a  href="admin_order.php?order-detail=<?php echo $row["orderID"] ?>">
						      		<button name="deleteItem" type="button" class=" btn btn-primary" style="border: 0px;border-radius: 5px;width: 100%;height: 35px;color: white">
			                Info</button>
						     </a>
 						  		</div>
 						  		<div class="col-md-6">
 						  			<a href="action/product_paid.php?edit=<?php echo $row["orderID"] ?>">
						      		<button name="deleteItem" type="button" class=" btn btn-primary" style="border: 0px;border-radius: 5px;width: 100%;height: 35px;color: white">
			                Paid</button>
						     </a>
 						  		</div>
 						  	</div>
						     

							      	
						   
							      	
						   </td>
					    </tr>
						<?php }} ?>
					  </tbody>
					</table>				  
		</div>
	</div>


<?php } ?>


<?php if(isset($_GET["order-paid"])) { ?>
		<div class="row" style="text-align: center;margin-top: 30px">
			<div class="col-md-12">
							<h1>ORDER HISTORY</h1>

			</div>
		</div>
		<div class="row" style="margin-top: 30px;">
			<div class="col-md-12">
				
				<nav class="navbar navbar-expand-lg ">
					
					<a class="navbar-brand header-link" href="admin_order.php?order-on_going" style="font-size: 20px;margin-left: 10px">On-Going</a>
					<a class="navbar-brand header-link" href="admin_order.php?order-paid" style="font-size: 20px;margin-left: 10px;text-decoration: underline">Paid</a>
					<a class="navbar-brand header-link" href="admin_order.php?order-delivered" style="font-size: 20px;margin-left: 10px;">Delivered</a>
				</nav>
			</div>
			<div class="col-md-12" style="padding-left: 40px">
				<form class="form-inline my-2 my-lg-0" style="text-align: right !important" action="" method="post">
			      <input class="form-control mr-sm-2" type="search" placeholder="Search By ID" aria-label="Search" name="searcchID">
			      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="search1">Search</button>
			    </form>
			</div>
			<div class="col-md-12" style="padding: 15px 40px" >

					<table class="table table-striped">
					  <thead>
					    <tr>
					      <th scope="col">id</th>
					      <th scope="col">Status</th>
					      <th scope="col">Name</th>
					      <th scope="col">Email</th>
					      <th scope="col">Phone Number</th>
					      <th scope="col">Date Ordered</th>
					      <th scope="col">Action</th>
					    </tr>
					  </thead>
					  <tbody>
						<?php  
						if (mysqli_num_rows($queryGetOrderHistory2) > 0) { 
				    		while ($row=mysqli_fetch_array($queryGetOrderHistory2)) {
						?>					  	
					    <tr>
					      <th scope="row"><?php echo $row["orderID"] ?></th>
					      <td><?php echo $row["statusName"] ?></td>
					      <td><?php echo $row["custName"] ?></td>
					      <td><?php echo $row["email"] ?></td>
					      <td><?php echo $row["phone"] ?></td>
					      <td><?php echo $row["bill_date"] ?></td>
					      <td>
 						  	<div class="row">
 						  		<div class="col-md-6">
 						  			<a  href="admin_order.php?order-detail=<?php echo $row["orderID"] ?>">
						      		<button name="deleteItem" type="button" class=" btn btn-primary" style="border: 0px;border-radius: 5px;width: 100%;height: 35px;color: white">
			                Info</button>
						     </a>
 						  		</div>
 						  		<div class="col-md-6">
 						  			<a href="action/product_delivered.php?edit=<?php echo $row["orderID"] ?>">
						      		<button type="button" class=" btn btn-primary" style="border: 0px;border-radius: 5px;width: 100%;height: 35px;color: white">
			                Delivered</button>
						     </a>
 						  		</div>
 						  	</div>
					      	
						   </td>
					    </tr>
					    <?php }} ?>
					  </tbody>
					</table>				  
		</div>
	</div>


<?php } ?>

<?php if(isset($_GET["order-delivered"])) { ?>
		<div class="row" style="text-align: center;margin-top: 30px">
			<div class="col-md-12">
							<h1>ORDER HISTORY</h1>

			</div>
		</div>
		<div class="row" style="margin-top: 30px;">
			<div class="col-md-12">
				
				<nav class="navbar navbar-expand-lg ">
					
					<a class="navbar-brand header-link" href="admin_order.php?order-on_going" style="font-size: 20px;margin-left: 10px">On-Going</a>
					<a class="navbar-brand header-link" href="admin_order.php?order-paid" style="font-size: 20px;margin-left: 10px">Paid</a>
					<a class="navbar-brand header-link" href="admin_order.php?order-delivered" style="font-size: 20px;margin-left: 10px;text-decoration: underline">Delivered</a>
				</nav>
			</div>
			<div class="col-md-12" style="padding-left: 40px">
				<form class="form-inline my-2 my-lg-0" style="text-align: right !important" action="" method="post">
			      <input class="form-control mr-sm-2" type="search" placeholder="Search By ID" aria-label="Search" name="searchID">
			      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="search1">Search</button>
			    </form>
			</div>
			<div class="col-md-12" style="padding: 15px 40px" >

					<table class="table table-striped">
					  <thead>
					    <tr>
					      <th scope="col">id</th>
					      <th scope="col">Status</th>
					      <th scope="col">Name</th>
					      <th scope="col">Email</th>
					      <th scope="col">Phone Number</th>
					      <th scope="col">Date Ordered</th>
					      <th style="text-align: center;" scope="col">Action</th>
					    </tr>
					  </thead>
					  <tbody>
					    <?php  
						if (mysqli_num_rows($queryGetOrderHistory3) > 0) { 
				    		while ($row=mysqli_fetch_array($queryGetOrderHistory3)) {
						?>					  	
					    <tr>
					      <th scope="row"><?php echo $row["orderID"] ?></th>
					      <td><?php echo $row["statusName"] ?></td>
					      <td><?php echo $row["custName"] ?></td>
					      <td><?php echo $row["email"] ?></td>
					      <td><?php echo $row["phone"] ?></td>
					      <td><?php echo $row["bill_date"] ?></td>

					      <td>		
 						  	<div class="row">
 						  		<div class="col-md-12">
 						  			<a href="admin_order.php?order-detail=<?php echo $row["orderID"] ?>">
						      		<button name="deleteItem" type="button" class=" btn btn-primary" style="border: 0px;border-radius: 5px;width: 100%;height: 35px;color: white">
			                Info</button>
						     </a>
 						  		</div>
 						  		
 						  	</div>
					      	
						   </td>
					    </tr>
					    <?php }} ?>
					  </tbody>
					</table>				  
		</div>
	</div>


<?php } ?>
<?php if(isset($_GET["order-detail"])) {


$_SESSION['sub_total'] = 0;

		if (isset($_GET["order-detail"])) {
			$billID = $_GET["order-detail"];
			$query1 = mysqli_query($connection,"SELECT * FROM orders , orderdetail, customer, address WHERE orders.orderID = $billID AND orderdetail.orderID = $billID AND orders.custID = customer.custID AND address.addressID = customer.addressID 	");

			if (mysqli_num_rows($query1) > 0) { 
			    while ($row=mysqli_fetch_array($query1)) {
			    	$_SESSION['bill_date'] = $row['bill_date'];
			    	$_SESSION['name'] = $row['custName'];
			    	$_SESSION['email'] = $row['email'];		
			    	$_SESSION['phone'] = $row['phone'];

			    	$_SESSION['country'] = $row['country'];
			    	$_SESSION['province'] = $row['province'];
			    	$_SESSION['city'] = $row['city'];
			    	$_SESSION['postalcode'] = $row['postalcode'];
			    	$_SESSION['address'] = $row['address'];
			    }
			}


		}
		$query = mysqli_query($connection,"SELECT * FROM orderdetail, productitem
									WHERE orderdetail.orderID = $billID AND orderdetail.productID = productitem.productID ");

		
									 ?>
	<div class="row" style="text-align: center;margin-top: 30px">
			<div class="col-md-12">
							<h1>ORDER DETAIL</h1>

			</div>
		</div>
		<div class="row" style="padding: 0px 300px;margin-top: 50px">
			<div class="col-md-6" style="padding-left: 0px">
				<p><?php 	echo $_SESSION['name'] ?></p>
				<p><?php 	echo $_SESSION['email'] ?></p>
				<p><?php 	echo $_SESSION['phone'] ?></p>
				
			</div>
			<div class="col-md-6" style="text-align: right;">
				<p>DATE : 	 <?php 	echo $_SESSION['bill_date'] ?></p>
				<p>BILL ID : <?php echo $billID ?></p>
				
			</div>
		</div>

		<div class="row" style="padding: 0px 300px 0px 300px;">	
		
			<div class="col-md-12" style="padding-left: 0px">

				  <div class="form-group">
					<table class="table table-striped">
					  <thead>
					    <tr>
					      <th scope="col">#</th>
					      <th scope="col">Name</th>
					      <th scope="col">Size</th>
					      <th scope="col">Qty</th>
					      <th scope="col">Price</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php 	
					  	$num = 1;
					  	$subTotal = 0;
					  	if (mysqli_num_rows($query) > 0) { 
			    				while ($row=mysqli_fetch_array($query)) { 

									if($row['size'] == 'Small' ){
										$price = $row['priceS'];
									}elseif ($row['size'] == 'Medium') {
										$price = $row['priceM'];
									}elseif ($row['size'] == 'Big') {
										$price = $row['priceB'];
									}



			    	?>
					    <tr>
					      <th scope="row"><?php 	echo $num; ?></th>
					      <td><?php 	echo $row['productName'];  ?></td>
					      <td><?php 	echo $row['size'];  ?></td>
					      <td><?php 	echo $row['productQTY'];  ?></td>
					      <td><?php 	echo $price ?></td>
 						  				    
						  </tr>
						<?php 	$num=+1;
								$subTotal += $price *  $row['productQTY'];


					}} ?>
					   
					  </tbody>
					</table>				  
				</div>


				  
				
			</div>
		</div>
		<div class="row" style="padding: 0px 300px 40px 300px">
			<div class="col-md-12" style="padding: 0px !important">
				<h3>Total Price : Rp. <?php 	echo $subTotal; ?></h3>
			</div>
			
		</div>
		<div class="row" style="padding: 0px 300px 0px 300px">
			<div class="col-md-12" style="padding: 0px !important">
				<h6>
					Shipping Address :
				</h6>
			</div>
			
		</div>
		<div class="row" style="padding: 0px 300px">
			<div class="col-md-8" style="padding : 0px !important;  ">
				<p><?php 	echo $_SESSION['address']; ?> , <?php 	echo $_SESSION['city']; ?>, <?php 	echo $_SESSION['province']; ?>,<?php 	echo $_SESSION['postalcode']; ?>, <?php 	echo $_SESSION['country']; ?></p>
			</div>
		</div>



		<div class="row" style="padding: 0px 300px 50px 300px">
			
			<div class="col-md-12" style="padding-right:  10px !important;padding-left: 0px !important">
				<a href="admin_order.php?order-on_going">
										<button style="width: 100%" type="submit" class="btn btn-primary">BACK TO ON GOING ORDER</button>

				</a>
				
			</div>			
		</div>
	
	<?php } ?>


	</body>
	</html>