	<!DOCTYPE html>
	<html>
	<head>
		<title>Grandma's Cookies</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


	    <link rel="stylesheet" href="main.css">
	    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>	
	    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="js/smoothScroll.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
		<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
		<!-- Bootstrap Date-Picker Plugin -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
		<style type="text/css">
		.video-container {
		  position: relative;
		}

		.overlay-desc {
		  background: rgba(0,0,0,0);
		  position: absolute;
		  top: 0; right: 0; bottom: 0; left: 0;
		  display: flex;
		  align-items: center;
		  justify-content: center;
		  margin-bottom: 100px
		}
		.header-link{
			color: black
		}
		.header-link:hover{
			color: white
		}
		.btn-buy{
			color: white;
			border-radius: 5px;
			background-color: #b5651d;
			border: 1px solid white
		}
		.btn-buy:hover{
			color: #b5651d;
			border-radius: 5px;
			background-color: #fff;
			border: 1px solid #b5651d	
		}
		</style>
	</head>
	<body style="background-color: white">
	<div class="video-container" >
		<div class="row" style="padding: 20px;position: absolute;z-index:10;">

			<div class="col-md-12">
				
				<nav class="navbar navbar-expand-lg ">
					
					<a class="navbar-brand header-link" href="#contact-us" style="font-size: 20px;margin-left: 10px;">CONTACT US</a>
					<a class="navbar-brand header-link" href="#our-product" style="font-size: 20px;margin-left: 10px;">OUR PRODUCT</a>
					<a class="navbar-brand header-link" href="admin.php" style="font-size: 20px;margin-left: 10px;">ADMIN</a>
				</nav>
			</div>

		</div>	
	   	<img style="width: 100%;opacity: 0.8" src="baking.gif" alt="">
     	<div class="overlay-desc">
     		<img src="assets/fuse_logo.png" alt="" style="width: 40%">
     	</div>
     	<div class="overlay-desc">
			<h1 style="color: black;margin-top: -150px">GRANDMA'S COOKIES</h1>
     	</div>
     	<div class="overlay-desc">
			<h4 style="color: black;margin-top: -70px;font-style: italic">The best cookies in town made by grandma.</h4>
     	</div>
     	<div class="overlay-desc" style="margin-top: 50px">
     		
			<a href="pre_order.php?order1">
				<button class="btn-buy" style="height: 60px;width:400px">PRE ORDER COOKIES NOW</button>
			</a> 
     	</div>
		
     
	</div>

		<div class="row bg-light" id="our-product" style="padding: 50px 300px;text-align: center">
			<div class="col-md-12" style="color: black;padding-bottom: 50px">
				<h1>TRY OUR MENU</h1>
			</div>

			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" src="assets/AC.jpeg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Almond Cookie</h5>
				    <p class="card-text"></p>
				  </div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" style="height: 200px" src="assets/CC.jpeg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Chocolate Chip Cookie</h5>
				    <p class="card-text"></p>
				  </div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" style="height: 200px" src="assets/HC.jpeg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Hazelnut Cookie</h5>
				    <p class="card-text"></p>
				  </div>
				</div>		
			</div>
		</div>
		<div class="row bg-light" style="padding: 50px 300px;text-align: center;margin-top: -50px">
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" src="assets/KK.jpeg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Kastengel Keju</h5>
				    <p class="card-text"></p>
				  </div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" style="height: 185px" src="assets/nastar.jpeg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Nastar</h5>
				    <p class="card-text"></p>
				  </div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" style="height: 185px" src="assets/PS.jpeg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Putri Salju</h5>
				    <p class="card-text"></p>
				  </div>
				</div>		
			</div>
		</div>
		<div class="row bg-light" style="padding: 50px 300px;text-align: center;margin-top: -50px">
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" src="assets/PBC.jpg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Peanut Butter Cookie</h5>
				    <p class="card-text"></p>
				  </div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" style="height: 285px" src="assets/CM.jpg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Chocolate Mint Cookie</h5>
				    <p class="card-text"></p>
				  </div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  <img class="card-img-top" style="height: 285px" src="assets/ORC.jpg" alt="Card image cap">
				  <div class="card-body">
				    <h5 class="card-title">Oatmeal Raisin Cookie</h5>
				    <p class="card-text"></p>
				  </div>
				</div>		
			</div>
		</div>






		 <!-- Footer -->
        <footer class="page-footer font-small blue pt-4" style="padding: 0px 50px" id="contact-us">

          <!-- Footer Links -->
          <div class="container-fluid text-center text-md-left">

            <!-- Grid row -->
            <div class="row">

              <!-- Grid column -->
              <div class="col-md-6 mt-md-0 mt-3">

                <!-- Content -->
                <h5 class="text-uppercase">Contact Us</h5>
                <p>WHATSAPP : +628 788 7280 719</p>
                <p>LINE : Falianeh</p>

              </div>
              <!-- Grid column -->

              <hr class="clearfix w-100 d-md-none pb-3">

             

              <!-- Grid column -->
              <div class="col-md-3 mb-md-0 mb-3">

                <!-- Links -->
                <h5 class="text-uppercase">Social Media</h5>

                <ul class="list-unstyled">
                  <li>
                    <a href="#!">Instagram</a>
                  </li>
                  <li>
                    <a href="#!">Facebook</a>
                  </li>
                  <li>
                    <a href="#!">Youtube</a>
                  </li>
                 
                </ul>

              </div>
              <!-- Grid column -->

            </div>
            <!-- Grid row -->

          </div>
          <!-- Footer Links -->

          <!-- Copyright -->
          <div class="footer-copyright text-center py-3">© 2020 Copyright:
            <a href=""> GRANDMA'S COOKIES</a>
          </div>
          <!-- Copyright -->

        </footer>
        <!-- Footer -->

	</body>
	</html>