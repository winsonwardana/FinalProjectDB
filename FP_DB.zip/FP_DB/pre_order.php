<?php 
include("database/config.php");

			session_start();

		if (isset($_POST['addItem'])) {
			$_SESSION['itemID'] = mysqli_real_escape_string($connection, $_POST['itemName']);
			$_SESSION['size'] = mysqli_real_escape_string($connection, $_POST['cookieSize']);
			$_SESSION['QTY'] = mysqli_real_escape_string($connection, $_POST['qty']);
			
				$queryAddItem = "INSERT INTO orderdetail (orderID, productID,productQTY, size) 
	      		VALUES 
	      			({$_SESSION['orderID']} ,{$_SESSION['itemID']}, {$_SESSION['QTY']}, '{$_SESSION['size']}' ) ";
			    		mysqli_query($connection, $queryAddItem);
		#header("Location: pre_order.php?order2");
		}

		if(isset($_POST['biodata'])){
			$_SESSION['date'] = date('Y-m-d', time());

			$_SESSION['name'] = mysqli_real_escape_string($connection, $_POST['name']);
			$_SESSION['email'] = mysqli_real_escape_string($connection, $_POST['email']);
			$_SESSION['phone'] = mysqli_real_escape_string($connection, $_POST['phone']);
			$_SESSION['country'] = mysqli_real_escape_string($connection, $_POST['country']);
			$_SESSION['province'] = mysqli_real_escape_string($connection, $_POST['province']);
			$_SESSION['city'] = mysqli_real_escape_string($connection, $_POST['city']);
			$_SESSION['postalcode'] = mysqli_real_escape_string($connection, $_POST['postalcode']);
			$_SESSION['address'] = mysqli_real_escape_string($connection, $_POST['address']);


			#$queryAdd = "INSERT INTO address
				$queryAddAddress = "INSERT INTO address
	      		(country,province,city,postalcode,address) 
	      		VALUES 
	      		('{$_SESSION['country']}', '{$_SESSION['province']}','{$_SESSION['city']}','{$_SESSION['postalcode']}','{$_SESSION['address']}' ) ";
	    		mysqli_query($connection, $queryAddAddress);

				# NGAMBIL BARIS PALING TERAKHIR
				$queryGetAddressID = mysqli_query($connection,"SELECT * FROM address WHERE addressId=(SELECT max(addressId) FROM address);");

				if (mysqli_num_rows($queryGetAddressID) > 0) { 
				        while ($row=mysqli_fetch_array($queryGetAddressID)) {
				                $_SESSION['addressID'] = $row['addressID'];
				        }
				      }
				      
				

			$queryAddCustomer = "INSERT INTO customer
	      		(custName,email,phone,addressID) 
	      		VALUES 
	      		('{$_SESSION['name']}', '{$_SESSION['email']}' ,  '{$_SESSION['phone']}' , '{$_SESSION['addressID']}' ) ";
	    		mysqli_query($connection, $queryAddCustomer);
				
			# NGAMBIL BARIS PALING TERAKHIR
				$queryGetCustomerID = mysqli_query($connection,"SELECT * FROM customer WHERE custID=(SELECT max(custID) FROM customer);");

				if (mysqli_num_rows($queryGetCustomerID) > 0) { 
				        while ($row=mysqli_fetch_array($queryGetCustomerID)) {
				                $_SESSION['custID'] = $row['custID'];
				        }
				      }
				      
				
			$queryAddOrder = "INSERT INTO orders
	      		(statusID,custID, bill_date) 
	      		VALUES 
	      		( 1 , {$_SESSION['custID']},'{$_SESSION['date']}' ) ";
	    		mysqli_query($connection, $queryAddOrder);



	    	$queryGetOrderID = mysqli_query($connection,"SELECT * FROM orders WHERE orderID=(SELECT max(orderID) FROM orders);");

				if (mysqli_num_rows($queryGetOrderID) > 0) { 
				        while ($row=mysqli_fetch_array($queryGetOrderID)) {
				                $_SESSION['orderID'] = $row['orderID'];
				        }
				      }
				      

		header("Location: pre_order.php?order2");

}



if(isset($_POST['cart'])){

		header("Location: pre_order.php?order3");

}


 ?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Grandma's Cookies</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


	    <link rel="stylesheet" href="main.css">
	    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>	
	    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="js/smoothScroll.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
		<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
		<!-- Bootstrap Date-Picker Plugin -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
		<style type="text/css">
		.video-container {
		  position: relative;
		}

		.overlay-desc {
		  background: rgba(0,0,0,0);
		  position: absolute;
		  top: 0; right: 0; bottom: 0; left: 0;
		  display: flex;
		  align-items: center;
		  justify-content: center;
		  margin-bottom: 100px
		}
		.header-link{
			color: black
		}
		.header-link:hover{
			color: blue
		}
		</style>
	</head>
	<body style="background-color: white">
				<div class="row" style="padding: 20px;position: absolute;z-index:10;">

			<div class="col-md-12">
				
				<nav class="navbar navbar-expand-lg  ">
					
					<a class="navbar-brand header-link" href="index.php" style="font-size: 20px;margin-left: 10px;">HOME</a>
				</nav>
			</div>

		</div>

		<div class="row" style="padding: 100px 300px 50px 300px;text-align: center;">
			<div class="col-md-12">
				<h1>PRE ORDER FORM</h1>
			</div>

			
		</div>
	<?php if(isset($_GET["order1"])) { ?>

		<div class="row" style="padding: 0px 300px 50px 300px;">	
		
			<div class="col-md-12">
							<form action=""  method="post"  role="form">

				  <div class="form-group">
				    <input type="text" class="form-control" name="name" placeholder="First Name" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
				  
				
			</div>
			<div class="col-md-12">
				<div class="form-group">
				    <input type="email" class="form-control" name="email" placeholder="Email" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
				    <input type="text" class="form-control" name="phone" placeholder="Phone" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
				    <input type="text" class="form-control" name="country" placeholder="Country" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
				    <input type="text" class="form-control" name="province" placeholder="Province" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
				    <input type="text" class="form-control" name="city" placeholder="City" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
				    <input type="text" class="form-control" name="postalcode" placeholder="Postal Code" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<textarea style="font-size: 14px" name="address" placeholder="Address" name="address" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>

				  </div>
			</div>						
			<div class="col-md-12">
				<button name="biodata"  style="width: 100%" type="submit" class="btn btn-primary">NEXT</button>
			</form>
			</div>
		

		</div>
	<?php } ?>

	<?php if(isset($_GET["order2"])) { ?>
		<div class="row" style="padding: 0px 300px">
			<div class="col-md-6" style="padding-left: 0px">
				<p><?php echo $_SESSION['name']; ?></p>
				<p><?php echo $_SESSION['email']; ?></p>
				<p><?php echo $_SESSION['phone']; ?></p>
				
			</div>
			<div class="col-md-6" style="text-align: right;">
				<p>DATE : <?php echo $_SESSION['date']; ?></p>
				<p>BILL ID : <?php echo $_SESSION['orderID']; ?></p>
				
			</div>
		</div>

		<div class="row" style="padding: 0px 300px 0px 300px;">	
		
			<div class="col-md-8" style="padding-left: 0px">

				  <div class="form-group">
					<table class="table table-striped">
					  <thead>
					    <tr>
					      <th scope="col">#</th>
					      <th scope="col">Name</th>
					      <th scope="col">Size</th>
					      <th scope="col">Qty</th>
					      <th scope="col">Price</th>
					      <th scope="col">Action</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php 
					  	$query = mysqli_query($connection,"SELECT * FROM orderdetail, productitem
									WHERE orderdetail.orderID = {$_SESSION['orderID']} AND orderdetail.productID = productitem.productID "); 



					  	$num = 1;
					  	$subTotal = 0;
					  	if (mysqli_num_rows($query) > 0) { 
			    				while ($row=mysqli_fetch_array($query)) { 

									if($row['size'] == 'Small' ){
										$price = $row['priceS'];
									}elseif ($row['size'] == 'Medium') {
										$price = $row['priceM'];
									}elseif ($row['size'] == 'Big') {
										$price = $row['priceB'];
									}



			    	


						?>
					    <tr>
					      <th scope="row"><?php 	echo $num; ?></th>
					      <td><?php 	echo $row['productName'];  ?></td>
					      <td><?php 	echo $row['size'];  ?></td>
					      <td><?php 	echo $row['productQTY'];  ?></td>
					      <td><?php 	echo $price ?></td>
 						  <td>
						     <a href="action/delete_order_detail.php?delete=<?php echo $row["orderdetailID"] ?>">
						      		<button name="deleteItem" type="button" class=" btn btn-danger" style="border: 0px;border-radius: 5px;width: 100%;height: 35px;color: white">
			                Delete</button>
						     </a>
							      	
						   </td>					    
						  </tr>
						  <?php 	$num=+1;
								$subTotal += $price *  $row['productQTY'];


					}} ?>
					  </tbody>
					</table>				  
				</div>


				  
				
			</div>
			<div class="col-md-4" style="background: black;border-radius: 5px;padding: 10px">

				<form action=""  method="post"  role="form">
					<div class="form-group">
						<select name="itemName" style="font-size: 14px" class="form-control" id="exampleFormControlSelect1">
							<?php 

							$query1 = mysqli_query($connection,"SELECT * FROM productitem"); 
							if (mysqli_num_rows($query1) > 0) { 
			    				while ($row=mysqli_fetch_array($query1)) { 
							 ?>
					      <option value="<?php echo $row['productID'];  ?>"><?php echo $row['productName'];  ?></option>
					  		<?php }} ?>
					    </select>
					</div>
					<div class="form-group">
						<select name="cookieSize" style="font-size: 14px" class="form-control" id="exampleFormControlSelect1">
					      <option value="Small">Small</option>
					      <option value="Medium">Medium</option>
					      <option value="Big">Big</option>
					    </select>
					</div>
				  <div class="form-group">
				    <input type="text" name="qty" class="form-control" placeholder="Insert Qty" id="exampleInputEmail1" aria-describedby="emailHelp">
				  </div>
				  <button name="addItem"  style="width: 100%" type="submit" class="btn btn-primary">ADD ITEM</button>

				  
				</form>
			</div>
		</div>
		<div class="row" style="padding: 0px 300px 40px 300px">
			<div class="col-md-12" style="padding: 0px !important">
				<h3>Total Price : Rp. <?php echo $subTotal	 ?></h3>
			</div>
			
		</div>
		<div class="row" style="padding: 0px 300px 0px 300px">
			<div class="col-md-12" style="padding: 0px !important">
				<h6>
					Shipping Address :
				</h6>
			</div>
			
		</div>
		<div class="row" style="padding: 0px 300px">
			<div class="col-md-8" style="padding : 0px !important;  ">
				<p><?php echo $_SESSION['address']; ?> , <?php echo $_SESSION['city']; ?>,<?php echo $_SESSION['province']; ?>, <?php echo $_SESSION['postalcode']; ?>, <?php echo $_SESSION['country']; ?></p>
			</div>
		</div>



		<div class="row" style="padding: 0px 300px 50px 300px">
			
			<div class="col-md-6" style="padding-right:  10px !important;padding-left: 0px !important">
				<a href="pre_order.php?order1">
										<button style="width: 100%" type="submit" class="btn btn-primary">CANCEL</button>

				</a>
				
			</div>	
			<div class="col-md-6" style="padding-left:   0px !important; padding-right: 0px !important">
				<form action="" method="post" role="form">
					<button name="cart"  style="width: 100%" type="submit" class="btn btn-primary">CHECK OUT</button>
				</form>
				
			</div>			
		</div>
	
	<?php } ?>

	<?php if(isset($_GET["order3"])) { ?>
		<div class="row" style="text-align: center;padding: 20px 500px 50px 500px">
			<div class="col-md-12">
				<h2>THANK YOU FOR ODERING</h2>
				<h6>Your order and transaction detail has been sent to your email</h6>
				<h7>Please complete your payment and cookies will be shipped to your address</h7>
				<a href="index.php">
					<button name="cart"  style="width: 100%; margin-top: 30px"  type="submit" class="btn btn-primary">BACK TO HOME</button>

				</a>
			</div>
			
		</div>

	<?php } ?>




	</body>
	</html>