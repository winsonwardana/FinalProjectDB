	<?php 
	include("database/config.php");
	if(isset($_POST['admin_login'])){
		$Name = mysqli_real_escape_string($connection, $_POST['Name']);
		$Pass = mysqli_real_escape_string($connection, $_POST['Pass']);
	
	if($Name == '1' && $Pass == '1'){

		header("Location: admin_order.php?order-on_going");
	}


	else{
		header("Location: admin.php?Failed");
				}			
			
	}

	


	 ?>

	<!DOCTYPE html>
	<html>
	<head>
		<title>Grandma's Cookies</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


	    <link rel="stylesheet" href="main.css">
	    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>	
	    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="js/smoothScroll.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
		<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
		<!-- Bootstrap Date-Picker Plugin -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
		<style type="text/css">
		.video-container {
		  position: relative;
		}

		.overlay-desc {
		  background: rgba(0,0,0,0);
		  position: absolute;
		  top: 0; right: 0; bottom: 0; left: 0;
		  display: flex;
		  align-items: center;
		  justify-content: center;
		  margin-bottom: 100px
		}
		.header-link{
			color: black
		}
		.header-link:hover{
			color: white
		}
		</style>
	</head>
	<body style="background-color: white">
	<div class="video-container" >
		<div class="row" style="padding: 20px;position: absolute;z-index:10;">

			<div class="col-md-12">
				
				<nav class="navbar navbar-expand-lg ">
					
					<a class="navbar-brand header-link" href="index.php" style="font-size: 20px;margin-left: 10px;">Home</a>
				</nav>
			</div>

		</div>	
	   	<img style="width: 100%;opacity: 0.8" src="baking.gif" alt="">

     	<div class="overlay-desc" style="margin-top: -210px">
     		<h4>Admin Login</h4>
     	</div>

     	<div class="overlay-desc">
     		<form action="" method="post">
			  <div class="form-group">
			    <label for="exampleInputEmail1"></label>
			    <input type="text" name="Name" class="form-control" placeholder="username" id="exampleInputEmail1" aria-describedby="emailHelp">
			  </div>
			  <div class="form-group">
			    <input type="password" name="Pass" class="form-control" placeholder="password" id="exampleInputPassword1">
			  </div>

			  <button name="admin_login" style="width: 100%" type="submit" class="btn btn-primary">login</button>
			  <?php if(isset($_GET['Failed'])) {

			   ?>
			 	<div class="form-group">
			 		<label style="color: red">Wrong Username or password</label>
			 	</div>
			 <?php } ?>
			</form>

   	</div>

		
     
	</div>







		 <!-- Footer -->
        <footer class="page-footer font-small blue pt-4" style="padding: 0px 50px" id="contact-us">

          <!-- Footer Links -->
          <div class="container-fluid text-center text-md-left">

            <!-- Grid row -->
            <div class="row">

              <!-- Grid column -->
              <div class="col-md-6 mt-md-0 mt-3">

                <!-- Content -->
                <h5 class="text-uppercase">Contact Us</h5>
                <p>WHATSAPP : +628 788 7280 719</p>
                <p>WHATSAPP : +628 111 3776 893</p>

              </div>
              <!-- Grid column -->

              <hr class="clearfix w-100 d-md-none pb-3">

             

              <!-- Grid column -->
              <div class="col-md-3 mb-md-0 mb-3">

                <!-- Links -->
                <h5 class="text-uppercase">Social Media</h5>

                <ul class="list-unstyled">
                  <li>
                    <a href="#!">Instagram</a>
                  </li>
                  <li>
                    <a href="#!">Facebook</a>
                  </li>
                  <li>
                    <a href="#!">Youtube</a>
                  </li>
                 
                </ul>

              </div>
              <!-- Grid column -->

            </div>
            <!-- Grid row -->

          </div>
          <!-- Footer Links -->

          <!-- Copyright -->
          <div class="footer-copyright text-center py-3">© 2020 Copyright:
            <a href=""> GRANDMA'S COOKIES</a>
          </div>
          <!-- Copyright -->

        </footer>
        <!-- Footer -->

	</body>
	</html>